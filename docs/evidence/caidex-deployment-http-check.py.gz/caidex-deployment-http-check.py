import concurrent.futures,json,ssl,time,urllib.request,urllib.error
from pathlib import Path
BASE='https://caidex.cn'
checks=[]
observations=[]
def call(path,body=None,headers=None):
    headers=dict(headers or {})
    if body is not None:
        headers['Content-Type']='application/json'
        body=json.dumps(body).encode()
    req=urllib.request.Request(BASE+path,data=body,headers=headers)
    try:
        response=urllib.request.urlopen(req,timeout=15)
    except urllib.error.HTTPError as error:
        response=error
    with response:
        return response.status,{k.lower():v for k,v in response.headers.items()},response.read(50000)
def check(name,passed,details=None):
    checks.append({'name':name,'passed':bool(passed),'details':details})
    assert passed,name
status,headers,body=call('/.well-known/oauth-authorization-server')
metadata=json.loads(body)
check('https_discovery_fixed_production_issuer',status==200 and metadata['issuer']==BASE+'/',metadata)
time.sleep(1.1)
status,headers,body=call('/authorize')
check('existing_authorization_protocol_page_https_no_store_csp',status==200 and headers.get('cache-control')=='no-store' and 'frame-ancestors' in headers.get('content-security-policy',''))
check('https_hsts_nosniff_referrer_headers',headers.get('strict-transport-security')=='max-age=31536000' and headers.get('x-content-type-options')=='nosniff' and headers.get('referrer-policy')=='no-referrer')
for action in ['me','sessions','chat-status','memory-status']:
    time.sleep(1.1)
    status,headers,body=call('/v1/auth/'+action,{})
    check('anonymous_'+action+'_denied',status==401,{'status':status})
for action,payload in [('register',{'email':'deployment-register@example.invalid','password':'synthetic deployment password never real'}),('recover',{'email':'deployment-recover@example.invalid'}),('change-email',{'email':'deployment-change@example.invalid','proof':'synthetic-not-real'})]:
    time.sleep(1.1)
    status,headers,body=call('/v1/auth/'+action,payload)
    check('disabled_mail_'+action+'_unavailable',status==503 and json.loads(body).get('error')=='temporarily_unavailable')
time.sleep(1.1)
status,headers,body=call('/v1/mail/events',{})
check('disabled_mail_callback_denied',status==401)
time.sleep(1.1)
status,headers,body=call('/v1/auth/me',{}, {'Origin':'https://untrusted.example.invalid','X-Forwarded-For':'127.0.0.1'})
check('untrusted_origin_not_granted_by_forwarded_header',status==401)
def flood(i):
    return call('/.well-known/oauth-authorization-server',headers={'X-Forwarded-For':f'203.0.113.{i+1}'})[0]
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
    statuses=list(pool.map(flood,range(24)))
check('real_client_ingress_burst_limited_despite_forged_forwarded_ips',429 in statuses and set(statuses)<= {200,429}, {str(s):statuses.count(s) for s in set(statuses)})
report={'server':'43.128.156.73','issuer':BASE+'/','checked_at':time.time(),'checks':checks,'real_email_sent':False,'formal_gui_verified':False}
Path('/tmp/caidex-deployment-http-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'failures':0,'burst_statuses':statuses}))
