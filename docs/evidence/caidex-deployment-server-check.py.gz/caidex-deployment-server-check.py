import hashlib,json,os,pwd,stat,subprocess,time,uuid
from pathlib import Path
checks=[]
def run(args,ok=True):
 r=subprocess.run(args,capture_output=True,text=True,timeout=360)
 if ok and r.returncode:
  raise RuntimeError('command failed: '+args[0]+' exit '+str(r.returncode))
 return r
def check(name,passed,details=None):
 checks.append({'name':name,'passed':bool(passed),'details':details})
 assert passed,name
def pg(sql,db='caidex',user='postgres',osuser='postgres',ok=True):
 return run(['sudo','-u',osuser,'psql','-X','-qAt','-h','/var/run/postgresql','-U',user,'-d',db,'-v','ON_ERROR_STOP=1','-c',sql],ok)
def ops(*args):
 r=run(['sudo','-u','postgres','python3','/opt/caidex/current/cloud/postgres/operations/backup.py','--socket','/var/run/postgresql','--database','caidex',*args])
 return json.loads(r.stdout)
release=Path('/opt/caidex/current').resolve()
head=run(['git','-C',str(release),'rev-parse','HEAD']).stdout.strip()
check('immutable_release_head',head=='c522a57c72709dc145e16f3c498fd9722a4082cb',head)
check('production_binary_sha256',hashlib.sha256((release/'bin/caidex-auth-service').read_bytes()).hexdigest()=='bb36671c0f54eb61267490ca992952b70d64f5dcfe680670ca698cfcca791e54')
check('credential_cli_sha256',hashlib.sha256((release/'bin/caidex').read_bytes()).hexdigest()=='96f4444bc2992f0eb15222b4550d7a3d915c611dce30ecbf32a7d9fcfcc4fde9')
config=json.loads(Path('/var/lib/caidex/config/config.json').read_text())
check('explicit_mail_disabled_no_sender',config['mail_disabled'] and not config['from'])
uid=pwd.getpwnam('caidex').pw_uid
for path,mode in [('/var/lib/caidex/config',0o700),('/var/lib/caidex/config/config.json',0o600),('/var/lib/caidex/secrets',0o700)]:
 s=os.lstat(path)
 check('private_owner_mode_'+Path(path).name,s.st_uid==uid and stat.S_IMODE(s.st_mode)==mode and not stat.S_ISLNK(s.st_mode))
check('secret_files_owner_only_without_reading_values',all(p.stat().st_uid==uid and stat.S_IMODE(p.stat().st_mode)==0o600 for p in Path('/var/lib/caidex/secrets').iterdir()))
meta=json.loads(pg("SELECT jsonb_build_object('postgres',current_setting('server_version'),'vector',(SELECT extversion FROM pg_extension WHERE extname='vector'),'schema',(SELECT max(version) FROM caidex.schema_migrations),'private_tables',(SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='caidex' AND c.relkind='r' AND c.relrowsecurity AND c.relforcerowsecurity),'tables',(SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='caidex' AND c.relkind='r'),'users',(SELECT count(*) FROM caidex.users),'challenges',(SELECT count(*) FROM caidex.auth_challenges),'mail_tasks',(SELECT count(*) FROM caidex.mail_tasks))").stdout)
check('pg17_vector082_schema5_all_private_tables_force_rls',meta['postgres'].startswith('17.11') and meta['vector']=='0.8.2' and meta['schema']==5 and meta['private_tables']==meta['tables']-1,meta)
check('http_smoke_created_no_account_challenge_or_mail',meta['users']==meta['challenges']==meta['mail_tasks']==0)
check('service_roles_no_owner_or_privilege_escape',pg("SELECT count(*)=2 AND bool_and(NOT(rolsuper OR rolbypassrls OR rolcreatedb OR rolcreaterole OR rolreplication) AND NOT pg_has_role(rolname,'caidex_owner','MEMBER') AND NOT pg_has_role(rolname,'caidex_guard','MEMBER')) FROM pg_roles WHERE rolname IN('caidex_auth_service','caidex_data_service')").stdout.strip()=='t')
for user,table in [('caidex_auth_service','messages'),('caidex_data_service','auth_credentials')]:
 check('role_'+user+'_cannot_read_'+table,pg('SELECT count(*) FROM caidex.'+table,user=user,osuser='caidex',ok=False).returncode!=0)
check('data_role_without_session_reads_no_body',pg('SELECT count(*) FROM caidex.messages',user='caidex_data_service',osuser='caidex').stdout.strip()=='0')
check('ubuntu_not_mapped_to_auth_role',pg('SELECT 1',user='caidex_auth_service',osuser='ubuntu',ok=False).returncode!=0)
check('service_os_user_not_postgres_admin',pg('SELECT 1',osuser='caidex',ok=False).returncode!=0)
listeners=run(['ss','-H','-lnt']).stdout.splitlines()
check('database_tcp_closed_and_app_loopback_only',not any(':5432 ' in line for line in listeners) and all('127.0.0.1:8080' in line for line in listeners if ':8080 ' in line),listeners)
check('firewall_only_ssh_http_https', 'Status: active' in run(['ufw','status']).stdout)
manifest=max(Path('/var/lib/caidex-backups').glob('snapshot-*.json'),key=lambda p:p.stat().st_mtime)
backup=json.loads(manifest.read_text())
archive=manifest.with_suffix('.dump')
check('real_private_backup_integrity_and_source',hashlib.sha256(archive.read_bytes()).hexdigest()==backup['sha256'] and archive.stat().st_size==backup['bytes'] and backup['source_head']==head and backup['max_bytes']==5_000_000_000 and stat.S_IMODE(archive.stat().st_mode)==0o600,{'bytes':backup['bytes'],'source_head':backup['source_head'],'retention_days':backup['retention_days'],'max_count':backup['max_count']})
checkpoint=Path('/var/lib/caidex-recovery')/('checkpoint-'+uuid.uuid4().hex+'.json')
ops('checkpoint',str(checkpoint))
target='caidex_restore_deploy_20261011'
restored=ops('restore',str(manifest),'--target',target,'--checkpoint',str(checkpoint))
check('pg1711_real_backup_restore_always_quarantined',restored['quarantined'] and not restored['old_sessions_valid'] and not restored['sync_enabled'] and restored['schema']==5 and restored['latest_checkpoint_applied'],restored)
check('restored_db_denies_both_runtime_connect',pg("SELECT NOT has_database_privilege('caidex_auth_service',current_database(),'CONNECT') AND NOT has_database_privilege('caidex_data_service',current_database(),'CONNECT')",db=target).stdout.strip()=='t')
check('restored_db_no_sessions_sync_or_risky_roles',pg("SELECT NOT EXISTS(SELECT FROM caidex.auth_sessions WHERE revoked_at IS NULL) AND NOT EXISTS(SELECT FROM caidex.users WHERE memory_enabled OR chat_sync_enabled)",db=target).stdout.strip()=='t')
# Only this probe's own reserved partial files are created; old user files are never touched.
pguid=pwd.getpwnam('postgres').pw_uid
pggid=pwd.getpwnam('postgres').pw_gid
probes=[]
for age in [6*86400+23*3600,0]:
 p=Path('/var/lib/caidex-backups')/('snapshot-'+str(int(time.time()-age))+'-'+uuid.uuid4().hex+'.partial')
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 os.fchown(fd,pguid,pggid)
 os.write(fd,b'synthetic retention probe')
 os.close(fd)
 probes.append(p)
run(['systemctl','start','caidex-prune.service'])
check('scheduled_expiry_margin_prunes_before_7days_and_keeps_fresh',not probes[0].exists() and probes[1].exists())
probes[1].unlink()
run(['systemctl','start','caidex-monitor.service'])
check('real_monitor_service_passes',run(['systemctl','show','caidex-monitor.service','-p','Result','--value']).stdout.strip()=='success')
probe=run(['systemd-run','--quiet','--wait','--collect','--unit=caidex-deployment-alert-probe','-p','OnFailure=caidex-alert@deployment-probe.service','/usr/bin/false'],ok=False)
time.sleep(1)
alert=run(['journalctl','-t','caidex-alert','--since','2 minutes ago','--no-pager','-o','cat']).stdout
check('actual_failure_triggers_local_operator_alert',probe.returncode!=0 and 'deployment-probe' in alert)
check('all_service_and_timers_enabled',all(run(['systemctl','is-enabled',name],ok=False).returncode==0 for name in ['caidex.service','caidex-backup.timer','caidex-prune.timer','caidex-monitor.timer','certbot.timer']))
print(json.dumps({'checked_at':time.time(),'head':head,'checks':checks,'failure_count':0,'backup':{'manifest':str(manifest),'bytes':backup['bytes']},'restore':restored,'mail_disabled':True,'synthetic_production_accounts_created':False},indent=2))
